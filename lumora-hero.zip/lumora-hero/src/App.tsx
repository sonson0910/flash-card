import { useEffect, useState } from 'react'
import { Menu, X } from 'lucide-react'

const videos = [
  {
    label: 'Golden Hour',
    src: 'https://d8j0ntlcm91z4.cloudfront.net/user_38xzZboKViGWJOttwIXH07lWA1P/hf_20260702_081127_0992a171-d3c6-4978-8213-0ec5df8b6d63.mp4',
  },
  {
    label: 'Still Water',
    src: 'https://d8j0ntlcm91z4.cloudfront.net/user_38xzZboKViGWJOttwIXH07lWA1P/hf_20260702_092026_dd05b805-ea0f-40b2-8c52-332b88502592.mp4',
  },
  {
    label: 'Deep Woods',
    src: 'https://d8j0ntlcm91z4.cloudfront.net/user_38xzZboKViGWJOttwIXH07lWA1P/hf_20260702_081042_df7202bf-bd80-4b2b-bbc6-1f09ba2870e9.mp4',
  },
  {
    label: 'Quiet Dawn',
    src: 'https://d8j0ntlcm91z4.cloudfront.net/user_38xzZboKViGWJOttwIXH07lWA1P/hf_20260702_080959_4cac5234-3573-464e-a5b7-76b94b8a7d61.mp4',
  },
]

const navItems = ['How It Works', 'Features', 'Pricing', 'Community']

const stats = [
  '60+ Deep Sessions',
  '12,000+ Creators',
  '4.8 User Satisfaction',
  'Intentional-First Design',
]

const systemFont = { fontFamily: 'system-ui, sans-serif' }

function App() {
  const [activeVideo, setActiveVideo] = useState(0)
  const [isTransitioning, setIsTransitioning] = useState(false)
  const [menuOpen, setMenuOpen] = useState(false)

  const isDarkMode = activeVideo === 2
  const heroColor = isDarkMode ? '#182C41' : '#ffffff'

  useEffect(() => {
    document.body.style.overflow = menuOpen ? 'hidden' : ''
    return () => {
      document.body.style.overflow = ''
    }
  }, [menuOpen])

  const switchVideo = (index: number) => {
    if (index === activeVideo || isTransitioning) return

    setIsTransitioning(true)
    setActiveVideo(index)
    window.setTimeout(() => setIsTransitioning(false), 1000)
  }

  return (
    <section className="relative h-screen w-full overflow-hidden bg-black">
      <div className="absolute inset-0 z-0">
        {videos.map((video, index) => (
          <video
            key={video.src}
            autoPlay
            muted
            loop
            playsInline
            preload="auto"
            className={`absolute inset-0 h-full w-full object-cover transition-opacity duration-1000 ease-in-out ${
              index === activeVideo ? 'opacity-100' : 'opacity-0'
            }`}
          >
            <source src={video.src} type="video/mp4" />
          </video>
        ))}
      </div>

      <img
        src="https://soft-zoom-63098134.figma.site/_assets/v11/0b4a435b2df2747593c43d7a1c9b4578f7d8d90c.png"
        alt=""
        aria-hidden="true"
        className="train-bob pointer-events-none absolute inset-0 z-[1] h-full w-full object-cover"
      />

      <div className="relative z-[2] flex h-full flex-col px-5 py-5 sm:px-8 sm:py-7 md:px-10 lg:px-14">
        <nav className="flex items-center justify-between">
          <a href="#" className="text-xl italic text-white sm:text-2xl">
            Lumora
          </a>

          <div className="liquid-glass hidden items-center gap-1 rounded-full px-1.5 py-1.5 md:flex">
            {navItems.map((item) => (
              <a
                key={item}
                href="#"
                style={systemFont}
                className="rounded-full px-4 py-2 text-sm text-white/90 transition-colors duration-300 hover:text-white"
              >
                {item}
              </a>
            ))}
            <a
              href="#"
              style={systemFont}
              className="ml-1 rounded-full bg-white px-5 py-2.5 text-sm font-medium text-[#182C41] transition-transform duration-300 hover:scale-[1.02]"
            >
              Get Started
            </a>
          </div>

          <button
            type="button"
            aria-label={menuOpen ? 'Close menu' : 'Open menu'}
            aria-expanded={menuOpen}
            onClick={() => setMenuOpen((value) => !value)}
            className="liquid-glass relative flex h-11 w-11 items-center justify-center rounded-full text-white md:hidden"
          >
            <Menu
              size={20}
              className={`absolute transition-all duration-300 ${
                menuOpen ? 'rotate-90 scale-75 opacity-0' : 'rotate-0 scale-100 opacity-100'
              }`}
            />
            <X
              size={20}
              className={`absolute transition-all duration-300 ${
                menuOpen ? 'rotate-0 scale-100 opacity-100' : '-rotate-90 scale-75 opacity-0'
              }`}
            />
          </button>
        </nav>

        <main className="flex flex-1 flex-col items-center justify-center text-center">
          <div
            className="flex w-full flex-col items-center transition-colors duration-700"
            style={{ color: heroColor }}
          >
            <div
              className={`liquid-glass mb-5 rounded-full px-4 py-2 text-[11px] sm:text-xs ${
                isDarkMode ? 'dark-glass' : ''
              }`}
              style={systemFont}
            >
              Over 10,000 minds already finding their clarity
            </div>

            <h1 className="max-w-4xl text-4xl leading-[1.1] sm:text-5xl md:text-7xl lg:text-[5.5rem]">
              Clarity in an Endlessly
              <br />
              Noisy Universe
            </h1>

            <p
              className="mt-5 max-w-xl px-2 text-sm leading-relaxed opacity-85 sm:text-base"
              style={systemFont}
            >
              Rise above the chaos of pings, infinite scrolling, and relentless demands. Discover how to protect your
              presence and create with intention.
            </p>

            <form
              onSubmit={(event) => event.preventDefault()}
              className={`liquid-glass mt-7 flex w-full max-w-[320px] items-center rounded-full p-1.5 sm:max-w-sm ${
                isDarkMode ? 'dark-glass' : ''
              }`}
            >
              <input
                type="email"
                aria-label="Email address"
                placeholder="Your Best Email"
                style={systemFont}
                className="min-w-0 flex-1 bg-transparent px-4 py-2.5 text-sm text-current outline-none placeholder:text-current/60"
              />
              <button
                type="submit"
                style={systemFont}
                className="shrink-0 rounded-full bg-white px-4 py-2.5 text-xs font-medium text-[#182C41] transition-transform duration-300 hover:scale-[1.02] sm:px-5 sm:text-sm"
              >
                Get Early Access
              </button>
            </form>

            <div
              className="mt-7 flex max-w-[95vw] gap-4 overflow-x-auto px-2 pb-1 text-xs sm:gap-6 sm:text-sm"
              style={systemFont}
            >
              {videos.map((video, index) => (
                <button
                  key={video.label}
                  type="button"
                  disabled={isTransitioning && index !== activeVideo}
                  onClick={() => switchVideo(index)}
                  className={`whitespace-nowrap border-b pb-1.5 transition-all duration-300 ${
                    index === activeVideo
                      ? 'border-current opacity-100'
                      : 'border-transparent opacity-50 hover:opacity-80'
                  }`}
                >
                  {video.label}
                </button>
              ))}
            </div>
          </div>
        </main>

        <div className="mt-auto flex flex-wrap items-center justify-center gap-x-3 gap-y-1 pb-1 text-center text-xs text-white/70 sm:text-sm md:gap-x-4" style={systemFont}>
          {stats.map((stat, index) => (
            <div key={stat} className="contents">
              <span>{stat}</span>
              {index < stats.length - 1 && <span className="hidden text-white/35 md:inline">|</span>}
            </div>
          ))}
        </div>
      </div>

      <div
        className={`fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm transition-all duration-500 md:hidden ${
          menuOpen ? 'pointer-events-auto opacity-100' : 'pointer-events-none opacity-0'
        }`}
        style={{ transitionTimingFunction: 'cubic-bezier(0.4,0,0.2,1)' }}
      >
        <button
          type="button"
          aria-label="Close menu"
          onClick={() => setMenuOpen(false)}
          className="liquid-glass absolute right-5 top-5 flex h-11 w-11 items-center justify-center rounded-full text-white"
        >
          <X size={20} />
        </button>

        <div className="flex h-full w-full flex-col items-center justify-center px-6">
          <div className="flex flex-col items-center gap-6">
            {navItems.map((item, index) => (
              <a
                key={item}
                href="#"
                onClick={() => setMenuOpen(false)}
                className={`text-3xl text-white transition-all duration-500 ${
                  menuOpen ? 'translate-y-0 opacity-100' : 'translate-y-4 opacity-0'
                }`}
                style={{
                  transitionDelay: menuOpen ? `${100 + index * 50}ms` : '0ms',
                  transitionTimingFunction: 'cubic-bezier(0.4,0,0.2,1)',
                }}
              >
                {item}
              </a>
            ))}
          </div>

          <a
            href="#"
            onClick={() => setMenuOpen(false)}
            style={{
              ...systemFont,
              transitionDelay: menuOpen ? '300ms' : '0ms',
              transitionTimingFunction: 'cubic-bezier(0.4,0,0.2,1)',
            }}
            className={`absolute bottom-10 rounded-full bg-white px-8 py-3.5 text-sm font-medium text-[#182C41] transition-all duration-500 ${
              menuOpen ? 'scale-100 opacity-100' : 'scale-90 opacity-0'
            }`}
          >
            Get Started
          </a>
        </div>
      </div>
    </section>
  )
}

export default App
